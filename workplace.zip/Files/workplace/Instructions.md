# Peer review sandbox

## Introduction


## Steps

**Step 1:** Upload the Django project.

a. Upload the project inside the workplace directory.
b. Right click on the workplace directory and select the upload option, it opens file system of your local machine.
c. Select the zip of your project and click on open button, your Django project will get uploaded to the shell.


**Step 2:**
Run the development server and open the project in the browser at URL http://127.0.0.1:8000/

**Step 3:**

Open a new tab in your web browser and open the peer review page. Review the website and answer the questions.

